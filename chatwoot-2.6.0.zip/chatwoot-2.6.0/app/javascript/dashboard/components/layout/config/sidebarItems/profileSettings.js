const profileSettings = () => ({
  parentNav: 'profileSettings',
  routes: ['profile_settings_index'],
  menuItems: [],
});

export default profileSettings;
