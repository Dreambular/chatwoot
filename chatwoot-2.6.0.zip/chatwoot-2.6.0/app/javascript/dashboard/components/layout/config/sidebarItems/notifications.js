const notifications = () => ({
  parentNav: 'notifications',
  routes: ['notifications_index'],
  menuItems: [],
});

export default notifications;
