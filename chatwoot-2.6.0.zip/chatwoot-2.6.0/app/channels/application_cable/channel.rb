class ApplicationCable::Channel < ActionCable::Channel::Base
end
